import torch
import numpy as np
import os

class RepeatedRemoveVideo:
    """
    RepeatedRemoveVideo - Remove frames every N (Video Only)
    Clean up frame rates, reduce file size, create time-lapses
    Works with: VIDEO inputs only
    """
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "video": ("VIDEO",),
                "remove_every": ("INT", {"default": 5, "min": 2, "max": 100, "step": 1}),
                "start_from": ("INT", {"default": 1, "min": 1, "max": 1000, "step": 1}),
            }
        }
    
    RETURN_TYPES = ("VIDEO", "INT")
    RETURN_NAMES = ("video", "remaining_frames")
    FUNCTION = "remove_frames_video"
    CATEGORY = "video/utils"
    
    def remove_frames_video(self, video, remove_every, start_from):
        """
        Remove frames every N frames - VIDEO only version
        """
        print(f"🔧 [RepeatedRemoveVideo] STARTING - remove_every: {remove_every}, start_from: {start_from}")
        
        if video is None:
            print("❌ [RepeatedRemoveVideo] ERROR: No video input")
            return (video, 0)
            
        print(f"📹 [RepeatedRemoveVideo] Video type: {type(video)}")
        
        video_tensor = None
        
        # Handle VIDEO input (VideoFromFile objects)
        if hasattr(video, 'get_stream_source'):
            try:
                stream_source = video.get_stream_source()
                print(f"📁 [RepeatedRemoveVideo] Video file: {os.path.basename(stream_source)}")
                
                if isinstance(stream_source, str) and os.path.exists(stream_source):
                    import cv2
                    
                    # Read video with OpenCV
                    cap = cv2.VideoCapture(stream_source)
                    frames = []
                    
                    while True:
                        ret, frame = cap.read()
                        if not ret:
                            break
                        # Convert BGR to RGB
                        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                        frames.append(frame_rgb)
                    
                    cap.release()
                    
                    if frames:
                        # Convert to tensor [1, frames, height, width, channels]
                        video_tensor = torch.from_numpy(np.stack(frames)).unsqueeze(0)
                        print("✅ [RepeatedRemoveVideo] Successfully read video file")
                        
            except Exception as e:
                print(f"❌ [RepeatedRemoveVideo] Video processing failed: {e}")
                return (video, 0)
        
        # Handle VIDEO tensor input
        elif isinstance(video, torch.Tensor) and video.ndim == 5:
            print("🎬 [RepeatedRemoveVideo] Detected VIDEO tensor")
            video_tensor = video
            
        else:
            print(f"❌ [RepeatedRemoveVideo] ERROR: Unsupported video type: {type(video)}")
            return (video, 0)
        
        if video_tensor is None:
            print("❌ [RepeatedRemoveVideo] ERROR: Could not process video")
            return (video, 0)
        
        print(f"🎯 [RepeatedRemoveVideo] Video tensor shape: {video_tensor.shape}")
        
        original_frames = video_tensor.shape[1]
        print(f"📈 [RepeatedRemoveVideo] Original frames: {original_frames}")
        
        # Convert to list of frames for processing
        frames_list = []
        frames_removed = 0
        
        for i in range(video_tensor.shape[1]):
            # Skip frames based on pattern (convert to 0-based index)
            if (i >= (start_from - 1)) and ((i - (start_from - 1)) % remove_every == 0):
                frames_removed += 1
                continue  # Skip this frame
            frames_list.append(video_tensor[:, i:i+1, :, :, :])
        
        print(f"🗑️ [RepeatedRemoveVideo] Frames removed: {frames_removed}")
        
        if frames_list:
            new_video_tensor = torch.cat(frames_list, dim=1)
            remaining_frames = new_video_tensor.shape[1]
            
            print(f"🎬 [RepeatedRemoveVideo] Output VIDEO shape: {new_video_tensor.shape}")
            print(f"✅ [RepeatedRemoveVideo] SUCCESS: {remaining_frames} frames remaining (removed {frames_removed} frames)")
            return (new_video_tensor, remaining_frames)
            
        else:
            print("⚠️ [RepeatedRemoveVideo] WARNING: All frames removed!")
            empty_video = video_tensor[:, :0, :, :, :]  # Empty VIDEO
            return (empty_video, 0)


class RepeatedRemoveImages:
    """
    RepeatedRemoveImages - Remove images every N (Image Batches Only)
    Clean up image sequences, reduce batch size, create subsets
    Works with: IMAGE batches only
    """
    
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "images": ("IMAGE",),
                "remove_every": ("INT", {"default": 5, "min": 2, "max": 100, "step": 1}),
                "start_from": ("INT", {"default": 1, "min": 1, "max": 1000, "step": 1}),
            }
        }
    
    RETURN_TYPES = ("IMAGE", "INT")
    RETURN_NAMES = ("images", "remaining_frames")
    FUNCTION = "remove_frames_images"
    CATEGORY = "image/utils"
    
    def remove_frames_images(self, images, remove_every, start_from):
        """
        Remove images every N images - IMAGE batch version
        """
        print(f"🔧 [RepeatedRemoveImages] STARTING - remove_every: {remove_every}, start_from: {start_from}")
        
        if images is None:
            print("❌ [RepeatedRemoveImages] ERROR: No images input")
            return (images, 0)
            
        print(f"🖼️ [RepeatedRemoveImages] Images type: {type(images)}")
        print(f"📊 [RepeatedRemoveImages] Images shape: {images.shape}")
        
        if not isinstance(images, torch.Tensor) or images.ndim != 4:
            print(f"❌ [RepeatedRemoveImages] ERROR: Expected 4D IMAGE tensor, got {type(images)} with ndim {images.ndim if hasattr(images, 'ndim') else 'N/A'}")
            return (images, 0)
        
        # IMAGE batch: [batch, height, width, channels]
        # Convert to video-like format for processing: [batch, 1, height, width, channels]
        images_video_format = images.unsqueeze(1)
        print(f"🔄 [RepeatedRemoveImages] Converted to video format: {images_video_format.shape}")
        
        original_images = images_video_format.shape[0]  # Number of images in batch
        print(f"📈 [RepeatedRemoveImages] Original images: {original_images}")
        
        # Convert to list of images for processing
        images_list = []
        images_removed = 0
        
        for i in range(images_video_format.shape[0]):
            # Skip images based on pattern (convert to 0-based index)
            if (i >= (start_from - 1)) and ((i - (start_from - 1)) % remove_every == 0):
                images_removed += 1
                continue  # Skip this image
            images_list.append(images_video_format[i:i+1, :, :, :, :])
        
        print(f"🗑️ [RepeatedRemoveImages] Images removed: {images_removed}")
        
        if images_list:
            new_images_video = torch.cat(images_list, dim=0)
            remaining_images = new_images_video.shape[0]
            
            # Convert back to IMAGE batch format: [batch, height, width, channels]
            new_images_batch = new_images_video.squeeze(1)
            
            print(f"🖼️ [RepeatedRemoveImages] Output IMAGE batch shape: {new_images_batch.shape}")
            print(f"✅ [RepeatedRemoveImages] SUCCESS: {remaining_images} images remaining (removed {images_removed} images)")
            return (new_images_batch, remaining_images)
            
        else:
            print("⚠️ [RepeatedRemoveImages] WARNING: All images removed!")
            empty_images = images[:0, :, :, :]  # Empty IMAGE batch
            return (empty_images, 0)


# Node registration - TWO SEPARATE NODES
NODE_CLASS_MAPPINGS = {
    "RepeatedRemoveVideo": RepeatedRemoveVideo,
    "RepeatedRemoveImages": RepeatedRemoveImages
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "RepeatedRemoveVideo": "🎬 RepeatedRemove Video",
    "RepeatedRemoveImages": "🖼️ RepeatedRemove Images"
}

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS"]